#include<stdio.h>

int main(void)
{
	int i,n;
	int v2[50],v1[50];
	void intary_rcpy(int v1[], const int v2[], int n);

	printf("������n��");
	scanf_s("%d", &n);

	for (i = 0; i < n; i++)
		scanf_s("%d", &v2[i]);

	intary_rcpy(v1, v2, n);

	printf("{");
	for (i = 0; i < n; i++)
		printf("%d", v1[i]);
	printf("}");

	getchar();
	getchar();

	return 0;
}

void intary_rcpy(int v1[], const int v2[], int n)
{
	int i;
	int temper=n-1;

	for (i = 0; i < n ; i++)
	{
		v1[i] = v2[temper--];
	}

	return v1;
		
}