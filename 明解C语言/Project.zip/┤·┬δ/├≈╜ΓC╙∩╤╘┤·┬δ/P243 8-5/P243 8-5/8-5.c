#include <stdio.h>

#define NUMBER 5
void brost(int a[], int n);

int main(void)
{
	int i;
	int height[NUMBER];

	printf("������%d�˵����ߡ�\n", NUMBER);
	for (i = 0; i < NUMBER; i++)
	{
		printf("%2d�ţ�", i + 1);
		scanf_s("%d", &height[i]);
	}

	brost(height, NUMBER);

	puts("���������С�");
	for (i = 0; i < NUMBER; i++)
		printf("%2d�ţ�%d\n", i + 1, height[i]);

	getchar();
	getchar();

	return 0;
}

void brost(int a[], int n)
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = n - 1; j > i; j--)
		{
			if (a[j - 1] > a[j])
			{
				int temp = a[j];
				a[j] = a[j - 1];
				a[j - 1] = temp;
			}
		}
	}
}