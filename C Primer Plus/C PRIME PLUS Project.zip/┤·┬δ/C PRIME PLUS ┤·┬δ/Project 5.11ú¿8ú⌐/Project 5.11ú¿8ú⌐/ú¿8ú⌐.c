#include<stdio.h>

int main(void)
{
	int integer_1, integer_2, sums;

	printf("This program computer moduli.\n");

	printf("Enter am integer to serve as the second opernd: ");
	scanf("%d", &integer_2);


	printf("Now enter the frist operant:");
	scanf("%d", &integer_1);

	while (integer_1 > 0)

	{
		sums = integer_2 % integer_1;
		printf("%d %% %d is %d", integer_1, integer_2, sums);

		printf("Enter next number for first operand (<= 0 to quit): ");
		scanf("%d", &integer_1);

	}
	printf("Done!\n");

	getchar();
	getchar();

	return 0;

}