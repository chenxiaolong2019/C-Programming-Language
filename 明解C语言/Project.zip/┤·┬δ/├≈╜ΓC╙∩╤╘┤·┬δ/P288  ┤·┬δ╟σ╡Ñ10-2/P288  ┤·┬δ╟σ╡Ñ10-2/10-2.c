#include <stdio.h>

int main(void)
{
	int n;
	double x;
	int a[3];

	printf("n       �ĵ�ַ:%p\n", &n);
	printf("x       �ĵ�ַ:%p\n", &x);
	printf("a[0]    �ĵ�ַ:%p\n", &a[0]);
	printf("a[1]    �ĵ�ַ:%p\n", &a[1]);
	printf("a[2]    �ĵ�ַ:%p\n", &a[2]);

	getchar();
	return 0;
}