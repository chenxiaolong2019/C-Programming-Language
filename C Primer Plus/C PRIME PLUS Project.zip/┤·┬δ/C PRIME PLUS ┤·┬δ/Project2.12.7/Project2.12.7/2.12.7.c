#include <stdio.h>

int smile(void);

int main(void)

{
	smile();
	smile();
	smile();
	printf("\n");
	smile();
    smile();
	printf("\n");
	smile();

	getchar();

	return 0;
}

int smile(void)
{
	printf("Smile!");

	return 0;
}