#include<stdio.h>
void adjust_point(int *n);

int main(void)
{
	int a;
	printf("������һ������:");
	scanf_s("%d", &a);

	adjust_point(&a);

	printf("%d", a);

	getchar();
	getchar();
	return 0;
}

void adjust_point(int *n)
{
	if (*n < 0)
		*n = 0;
	else if (*n > 100)
		*n = 100;
}