#include<stdio.h>

int main(void)
{
	int i, ch;
	int cnt[10] = { 0 };

	while ((ch = getchar()) != EOF)
	{
		if (ch >= '0' && ch <= '9')
		{
			cnt[ch - '0']++;
		}
	}

	puts("�����ַ����ֵĴ���");
	for (i = 0; i < 10; i++)
	{
		printf("'%d' : ", i);
		for (cnt[i] = cnt[i]; cnt[i] > 0; cnt[i]--)
		{
			printf("*");
		}

		printf("\n");
	}
	getchar();
	getchar();

	return 0;
}