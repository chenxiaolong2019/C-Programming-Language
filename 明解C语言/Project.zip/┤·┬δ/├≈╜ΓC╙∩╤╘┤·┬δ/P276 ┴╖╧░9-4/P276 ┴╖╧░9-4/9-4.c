#include<stdio.h>
void null_string(char s[]);

int main(void)
{
	char str[10];

	printf("�������ַ�����");
	scanf("%s", str);

	null_string(str);

	getchar();
	getchar();

	return 0;
}

void null_string(char s[])
{
	int i = 0;
	for (i = 0; i < 10; i++)
	{
		s[i] = '\0';

		putchar(s[i]);
	}
}
