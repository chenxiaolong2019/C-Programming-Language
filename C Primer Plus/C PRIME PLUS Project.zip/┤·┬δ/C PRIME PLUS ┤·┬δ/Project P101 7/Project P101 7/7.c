#include <stdio.h>
#include <float.h>
int main(void)
{
	double a;
	float b;
	a = 1.0 / 3.0;
	b = 1.0 / 3.0;

	printf("a=%.6le      b=%.6f", a,b);

	printf("\n");

	printf("a=%.12le     b=%.12f", a,b);

	printf("\n");

	printf("a=%.16le     b=%.16f", a,b);

	printf("\n");

	printf("FLT_DIG=%d", FLT_DIG);

	printf("\n");

	printf("DBL_DIG=%d", DBL_DIG);

	getchar();
	getchar();
	getchar();

	return 0;

}