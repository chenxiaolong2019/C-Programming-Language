#include<stdio.h>

unsigned rrotate(unsigned x, int n);
unsigned lrotate(unsigned x, int n);

int count_bits(unsigned x);
int int_bits(void);

int main(void)
{
	unsigned x,n;
	puts("������Ҫ�ƶ���λ����");
	scanf_s("%u", &n);

	puts("�������޷���������");
	scanf_s("%u", &x);

	printf("���ƺ��ֵ��\n");
	lrotate(x, n);
	puts("\n");
	printf("���ƺ��ֵ��\n");
    rrotate(x, n);

	getchar();
	getchar();
	return 0;
}
unsigned rrotate(unsigned x, int n)
{
	int i;
	x >>= n;
	for (i = int_bits() - 1; i >= 0; i--)
		putchar(((x >> i) & 1U) ? '1' : '0');
}

unsigned lrotate(unsigned x, int n)
{
	int i;
	x <<= n;
	for (i = int_bits() - 1; i >= 0; i--)
		putchar(((x >> i) & 1U) ? '1' : '0');
}

int int_bits(void)
{
	return count_bits(~0U);
}

int count_bits(unsigned x)
{
	int bits = 0;
	while (x)
	{
		if (x & 1U)
			bits++;
		x >>= 1;
	}
	return bits;
}