//ʹ�ñ䳤����ĺ���
#include<stdio.h>
#define ROWS 3
#define COLS 3
int sum2d(int rows, int cols, int ar[rows][cols]);
int main(void)
{
	int i, j;
	int rs = 3;
	int cs = 10;
	int junk[ROWS][COLS] = {
		{2,4,6,8},

	}
}