#include <stdio.h>

int main(void)
{
	char let;
	char start;
	char start_up;
	char start_down;
	int space;

	printf("enter a letter: ");
	scanf("%c", &let);

	for (start = 'A'; start <= let; start++)
	{
		for (space = let - 1; space >= start; space--)
			printf(" ");

		for (start_up = 'A'; start_up <= start; start_up++)
			printf("%c", start_up);

		for (start_down = start - 1; start_down >= 'A'; start_down--)
			printf("%c", start_down);

		printf("\n");
	}
	
	getchar();

	getchar();

	return 0;
}