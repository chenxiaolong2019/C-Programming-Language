#include<stdio.h>
double min(double x, double y);

int main(void)
{
	double a, b;
	printf("����������ֵ��\n");
	scanf("%lf %lf", &a, &b);
	double min(a, b);

	printf("��С��ֵ�ǣ�%lf",min(a,b));

	getchar();
	getchar();

	return 0;
}

double min(double x, double y)
{
	double min;

	if (x > y)
		min = y;
	else
		min = x;

	return min;
}