#include<stdio.h>

int main(void)
{
	int num, count,count1,count2,count3;

	printf("��ʾ���ٸ�*: ");
	scanf_s("%d", &num);

	count1 = num / 5;
	count2 = num % 10;

	for (count = 0; count < count1; count++)
		printf("*****\n");

	for (count3 = 0; count3 < count2; count3++)
		printf("*");

	getchar();
	getchar();
	return 0;
}