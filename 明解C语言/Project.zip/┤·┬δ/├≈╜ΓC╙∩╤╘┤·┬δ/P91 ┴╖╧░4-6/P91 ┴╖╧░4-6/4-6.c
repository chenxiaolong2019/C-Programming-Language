#include<stdio.h>

int main(void)
{
	int num1, num2;
	num2 = 2;

	printf("������һ������: ");
	scanf("%d", &num1);

	while (num2 <= num1)
	{
		printf("%d", num2);
		printf(" ");
		num2 = num2 + 2;
	}

	getchar();
	getchar();

	return 0;
}