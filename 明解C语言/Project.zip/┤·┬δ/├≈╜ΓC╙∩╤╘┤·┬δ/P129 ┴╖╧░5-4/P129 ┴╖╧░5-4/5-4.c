#include<stdio.h>

int main(void)
{
	int i,j;
	j = 4;
	int a[5] = { 17,23,36 };
	int b[5];

	for (i = 0; i < 5; i++)
	{
		b[j] = a[i];
		j--;
	}

	puts("a     b");
	puts("-------");
	for (i = 0, j = 0; i < 5, j < 5; i++, j++)
		printf("%4d%4d\n", a[i], b[j]);

	getchar();
	return 0;
		
		
}