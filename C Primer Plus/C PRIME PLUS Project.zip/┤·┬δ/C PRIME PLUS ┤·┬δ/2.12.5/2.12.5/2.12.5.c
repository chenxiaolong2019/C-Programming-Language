#include <stdio.h>

int br(void);
int ic(void);

int main(void)
{
	br();
	ic();
	printf("India,China,\nBrazil,Russia\n");

	getchar();

	return 0;

}

int br()
{
	printf("Brazil,Russia,");

	return 0;
}

int ic()
{
	printf("India,China\n");

	return 0;
}