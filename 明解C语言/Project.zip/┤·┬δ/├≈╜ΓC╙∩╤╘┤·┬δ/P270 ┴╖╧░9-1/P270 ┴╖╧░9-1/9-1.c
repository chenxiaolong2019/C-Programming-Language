#include<stdio.h>

int main(void)
{
	char str[] = "ABC\0DEF";

	printf("\"%s\".",str);

	getchar();
	return 0;
}