#include<stdio.h>

int main(void)
{
	int integer,num,count,num2;

	printf("����ֵ�� ");
	scanf_s("%d", &integer);

	num = integer % 2;

	if (num != 0)
	{
		for (num2 = 1; num2 <= integer; num2 += 2)
		{
			printf("%d ", num2);
		}
	}
	else
		printf("����ż��");

	getchar();
	getchar();

	return 0;
}