#include<stdio.h>

int main(void)
{
	int ch;
	int count=0;

	while ((ch = getchar())!= EOF)
	{
		if (ch = '\n')
			count++;
	}
	count = count / 2 ;

	printf("����:%d", count);

	getchar();
	getchar();

	return 0;
}