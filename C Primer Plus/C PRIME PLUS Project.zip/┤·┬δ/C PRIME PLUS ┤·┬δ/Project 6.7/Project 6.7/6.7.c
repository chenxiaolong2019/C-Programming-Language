//��ЩֵΪ��
#include<stdio.h>
int main(void)
{
	int n = 3;

	while (n)
		printf("%2d is ture\n", n--);
	printf("%2d is false\n", n);

	n = -3;
	while (n)
		printf("%2d is ture\n", n++);
	printf("%2d is false\n", n);

	getchar();
	return 0;
}