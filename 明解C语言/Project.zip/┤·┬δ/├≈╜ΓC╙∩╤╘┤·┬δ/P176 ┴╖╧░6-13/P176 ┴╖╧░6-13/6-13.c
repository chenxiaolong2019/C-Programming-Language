#include<stdio.h>
void mat_add(const int tensu[2][4][3], int sum);
void mat_printf(const int tensu[2][4][3], int count);
void  mat_sum(int n);

int main(void)
{
	int count;

	int tensu[2][4][3] = { {{91,63,78},{67,72,46},{89,34,53},{32,54,34}},
						   {{97,67,82},{73,43,46},{97,56,21},{85,46,35}} };
	int sum[4][3];   //�ܷ�

	for (count = 0; count < 2; count++)
	{
		printf("��%d�ο��Է���\n",count+1);
		mat_printf(tensu, count);
	}
	puts("�ܷ�");   mat_add(tensu, sum);


	getchar();
	getchar();

	return 0;
}

void mat_add(const int tensu[2][4][3], int sum)
{
	int i,j;
	for (i = 0; i < 4; i++)
	{
		for (j = 0;j < 3; j++)
		{
			printf("%d ", tensu[0][i][j] + tensu[1][i][j]);
		}
		printf("\n");
	}
}

void mat_printf(const int tensu[2][4][3], int count)
{
	int a, b;
	for (a = 0; a < 4; a++) 
	{
		for (b = 0; b < 3; b++)
		{
			printf("%d ", tensu[count][a][b]);
		}
		printf("\n");
	} 
}