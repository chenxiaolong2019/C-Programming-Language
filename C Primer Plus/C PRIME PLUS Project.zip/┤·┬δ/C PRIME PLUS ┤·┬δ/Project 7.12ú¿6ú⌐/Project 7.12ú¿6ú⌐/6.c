#include <stdio.h>

int main(void)
{
	char ch;
	char ch_pre = 0;
	int n = 0;

	printf("enter something to test the program: ");

	while ((ch = getchar()) != '#')
	{
		if ('i' == ch)
		{
			if ('e' == ch_pre)
				n++;
		}
		ch_pre = ch;
	}
	printf("ei has appeared %d times.\n", n);

	getchar();
	getchar();

	return 0;
	
}