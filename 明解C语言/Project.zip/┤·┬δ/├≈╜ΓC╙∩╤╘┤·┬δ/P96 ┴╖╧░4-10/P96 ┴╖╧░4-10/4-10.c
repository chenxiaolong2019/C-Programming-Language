#include<stdio.h>

int main(void)
{
	int num1, num2;
	num2 = 0;

	printf("�������� ");
	scanf_s("%d", &num1);

	while (num2++ < num1)
		printf("*\n");

	getchar();
	getchar();

	return 0;
}