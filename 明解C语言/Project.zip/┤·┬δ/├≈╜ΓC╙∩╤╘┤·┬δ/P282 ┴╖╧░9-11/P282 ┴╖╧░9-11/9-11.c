#include<stdio.h>
#define NUMBER 4
#define IDX_NUM 128
void put_strary(char s[][IDX_NUM], int n);

int main(void)
{
	int count = 0;
	char cs[NUMBER][IDX_NUM];
	
	for (count = 0; count < NUMBER; count++)
	{
		scanf("%s", cs[count]);
		
		if (strcmp(cs[count], "$$$$$") == 0)
			break;
	}

	put_strary(cs, NUMBER);

	getchar();
	getchar();

	return 0;
	
}

void put_strary(char s[][IDX_NUM], int n)
{
	int i;
	for (i = 0; i < n; i++)
	{
		if (strcmp(s[i], "$$$$$") == 0)
			break;
		printf("s[%d]=\"%s\"\n", i, s[i]);
	}
}
