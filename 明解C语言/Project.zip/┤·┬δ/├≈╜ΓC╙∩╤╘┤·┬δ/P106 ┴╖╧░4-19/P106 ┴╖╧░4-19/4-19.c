#include<stdio.h>

int main(void)
{
	int i, n;
	int count = 0;

	printf("����ֵ: ");
	scanf_s("%d", &n);

	for (i = 1; i <= n; i++)
		if (n%i == 0)
		{
			printf("%d", i);
			count += 1;
		}
	putchar('\n');
	printf("Լ����%d��", count);

	getchar();
	getchar();

	return 0;
}