//ָ����ַ���
#include<stdio.h>
int main(void)
{
	const char * mesg = "Don't ba a fool!";
	const char * copy;

	copy = mesg;
	printf("%s\n", copy);
	printf("mesg = %s; &mesg = %p; value = %p\n", mesg, &mesg, mesg);
	printf("copy = %s; &mesg = %p; value = %p\n", copy, &copy, copy);

	getchar();
	return 0;

}