#include<stdio.h>
int main(void)
{
	int num;
	int i = 1;
	printf("��������");
	scanf_s("%d", &num);

	while (i <= num) {
		if (i++ % 2)

			putchar('+');

		else

			putchar('-');

	}

	getchar();
	getchar();

	return 0;
}