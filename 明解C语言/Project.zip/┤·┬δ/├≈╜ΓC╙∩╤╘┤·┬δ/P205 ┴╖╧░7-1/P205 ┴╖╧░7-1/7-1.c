#include<stdio.h>

int main(void)
{
	int n;
	 
	printf("sizeof 1 = %d   ", sizeof 1);
	printf("sizeof(unsigned) -1 = %d   ", sizeof(unsigned) -1);
	printf("sizeof n+2 = %d  \n", sizeof n+2);

	printf("sizeof +1 = %d   ", sizeof +1);
	printf("sizeof(doulbe) -1 = %d   ", sizeof(double) -1);
	printf("sizeof��n+2�� = %d  \n", sizeof(n + 2));

	printf("sizeof -1 = %d   ", sizeof -1);
	printf("sizeof��(doulbe) -1�� = %d   ", sizeof((double) - 1));
	printf("sizeof��n+2.0�� = %d  \n", sizeof(n + 2.0));

	getchar();

	return 0;
}