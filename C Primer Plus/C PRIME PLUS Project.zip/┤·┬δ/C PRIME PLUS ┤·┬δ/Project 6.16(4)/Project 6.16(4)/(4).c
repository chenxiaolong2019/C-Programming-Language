
#include <stdio.h>

int main(void)
{
	int i, j;
	char ch = 'A';

	for (i = 1; i <= 6; i++)
	{
		for (j = 1; j <= i; j++, ch++)
		{
			printf("%c", ch);
		}
		printf("\n");
	}

	getchar();

	return 0;
}