#include<stdio.h>
void sorts(int *n1, int *n2, int *n3);
void sorts_2(int *n1, int *n2, int *n3);
void sorts_3(int *n1, int *n2, int *n3);
void sorts_4(int *n1, int *n2, int *n3);

int main(void)
{
	int a, b, c;
	puts("����������������");
	scanf_s("%d", &a);  scanf_s("%d", &b);  scanf_s("%d", &c);

	sorts(&a, &b, &c);

	printf("���������ְ������������ǣ�%d  %d  %d",a,b,c);

	getchar();
	getchar();
	return 0;
}

void sorts(int *n1, int *n2, int *n3)
{
	if (*n1 > *n2)
		sorts_2(n1, n2, n3);
	if (*n2 > *n1)
		sorts_3(n1, n2, n3);
	if (*n3 > *n1)
		sorts_4(n1, n2, n3);
}

void sorts_2(int *n1, int *n2, int *n3)
{ 
	int temp;
	if (*n3 > *n2)
	{
		temp = *n2;
		*n2 = *n3;
		*n3 = temp;
	}
}

void sorts_3(int *n1, int *n2, int *n3)
{
	int temp_1, temp_2;
	if (*n3 > *n2)
	{
		temp_1 = *n1;
		*n1 = *n3;
		*n3 = temp_1;
	}
}

void sorts_4(int *n1, int *n2, int *n3)
{
	int temp_1,temp_2;
	if (*n2 > *n3)
	{
		temp_1 = *n3;
		temp_2 = *n1;
		*n1 = *n2;
		*n2 = temp_1;
		*n3 = temp_2;
	}
}