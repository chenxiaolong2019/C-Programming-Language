#include<stdio.h>;

int main(void)
{
	float x = 0, y;
	int i;
	double sum1=0, sum2=0;

	for (i = 0; i <= 100; i++)
	{
		y = i / 100.0;
		printf("x = %f     x = %f\n", y, x);
		sum1 += y;
		sum2 += x;

		x += 0.01;
	}
	printf("sum1=%f    sum2=%f", sum1, sum2);

	getchar();
	return 0;
}