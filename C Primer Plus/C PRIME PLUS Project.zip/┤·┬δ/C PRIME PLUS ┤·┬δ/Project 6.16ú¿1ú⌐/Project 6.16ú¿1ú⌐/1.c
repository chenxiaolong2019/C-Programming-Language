#include<stdio.h>
#define SIZE 26
int main(void)
{
	char ch[SIZE];
	int index;
	char letter;
	
	for (letter = 'a', index = 0; letter <= 'z'; index++,letter++)
	{
		ch[index] = letter;
		printf("%c", letter);

	}

	getchar();
	return 0;
}