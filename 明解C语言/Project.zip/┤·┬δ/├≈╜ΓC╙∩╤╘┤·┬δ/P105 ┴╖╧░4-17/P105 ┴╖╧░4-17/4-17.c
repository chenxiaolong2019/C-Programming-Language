#include<stdio.h>

int main(void)
{
	int integer,power;

	printf("n��ֵ��");
	scanf_s("%d", &power);

	for (integer = 1; integer <= power; integer++)
		printf("%d�Ķ��η���%d\n", integer, integer*integer);

	getchar();
	getchar();
	return 0;
}