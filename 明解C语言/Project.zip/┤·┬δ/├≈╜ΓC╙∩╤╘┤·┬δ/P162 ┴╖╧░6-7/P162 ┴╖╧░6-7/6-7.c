#include<stdio.h>

int main(void)
{
	void hello(void);

    hello();

	getchar();
	return 0;
}

void hello(void)
{
	printf("���\n");
}