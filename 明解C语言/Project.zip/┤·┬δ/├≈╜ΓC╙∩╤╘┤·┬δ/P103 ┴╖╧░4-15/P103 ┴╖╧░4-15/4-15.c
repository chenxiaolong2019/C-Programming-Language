#include<stdio.h>

int main(void)
{
	double start, end, interval,count,count2,weight;

	printf("��ʼ��ֵ�� ");
	scanf_s("%lf", &start);

	printf("������ֵ�� ");
	scanf_s("%lf", &end);

	printf("�����ֵ�� ");
	scanf_s("%lf", &interval);

	for (start = start; start <= end; start += interval)
	{
		weight = (start - 80)*0.7;
		printf("%dcm         %.2lfkg\n", (int)start, weight);
	}

	getchar();
	getchar();

	return 0;

}