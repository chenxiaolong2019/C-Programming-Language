#include<stdio.h>
int main(void)
{
	int bits = 0;
	unsigned x;
	x = ~0U;
	while(x)
	{
		if (x & 1U)
			bits++;
		x >>= 1;
	}

	printf("%d", bits);

	getchar();
	return 0;
}