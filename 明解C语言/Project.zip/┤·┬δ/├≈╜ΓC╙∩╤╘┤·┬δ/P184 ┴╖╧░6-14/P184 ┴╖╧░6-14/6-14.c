#include<stdio.h>
double a;

int main(void)
{
	int i;
	static double b;
	static double c[5];

	printf("a = %d\n", a);
	printf("b = %d\n", b);

	for (i = 0; i < 5; i++)
		printf("c[%d] = %d\n", i, c[i]);

	getchar();
	return 0;
}
