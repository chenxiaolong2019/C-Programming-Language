
#include <stdio.h>

int main(void)
{
	char ch;
	int n = 0;

	printf("Enter something(# to quit): ");

	while ((ch = getchar()) != '#')
	{
		if ((n % 8 == 0) && n != 0)
			printf("\n");
		printf("%c-%d,", ch, ch);

		n++;
	}

	getchar();
	getchar();

	return 0;
}