#include<stdio.h>
void larger_of(double *x, double *y);

int main(void)
{
	double num1, num2;
	printf("����������ֵ��\n");
	
	while (scanf("%lf %lf", &num1, &num2) == 2)
	{
		printf("Now num1=%lf  num2=%lf\n", num1, num2);
		larger_of(&num1, &num2);
		printf("Now num1=%lf  num2=%lf\n", num1, num2);

		printf("enter the next two number: \n");
	}
	printf("Bye.");

	getchar();
	return 0;
}

void larger_of(double *x, double *y)
{
	if (*x >= *y)
		*y = *x;
	else
		*x = *y;
}