#include<stdio.h>

int main(void)
{
	int num1;
	int num2;
	int num3;

	num1 = 15;
	num2 = 37;
	num3 = num1 - num2;

	printf("15��ȥ37�Ľ����%d", num3);

	getchar();
	return 0;
}