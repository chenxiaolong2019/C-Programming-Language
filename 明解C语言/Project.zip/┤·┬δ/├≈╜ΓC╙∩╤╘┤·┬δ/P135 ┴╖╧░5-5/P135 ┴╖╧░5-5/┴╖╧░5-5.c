#include<stdio.h>
#define NUMBER 8

int main(void)
{
	int i,j;
	int x[NUMBER];

	for (i = 0; i < NUMBER; i++)

	{
		printf("x[%d]:", i);
		scanf_s("%d", &x[i]);
	}

	j = NUMBER / 2;

	for (i = 0; i < (int)j; i++)
	{
		int temp = x[i];
		x[i] = x[NUMBER-1 - i];
		x[NUMBER-1 - i] = temp;
	}

	puts("���������ˡ�");
	for (i = 0; i < NUMBER; i++)
		printf("x[%d]=%d\n", i, x[i]);

	getchar();
	getchar();

	return 0;
}