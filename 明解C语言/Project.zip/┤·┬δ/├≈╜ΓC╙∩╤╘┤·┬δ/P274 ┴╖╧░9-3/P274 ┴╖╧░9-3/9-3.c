#include<stdio.h>

int main(void)
{
	int i;
	char s[5][128];

	for (i = 0; i < 5; i++)
	{
		printf("s[%d]:", i);
		scanf("%s", s[i]);
		if (strcmp(s[i], "$$$$$") == 0)
			break;
	}

	for (i = 0; i < 5; i++)
	{
		if (strcmp(s[i], "$$$$$") == 0)
			break;
		printf("s[%d] = \"%s\"\n", i, s[i]);
	}

	getchar();
	getchar();

	return 0;
}