#include<stdio.h>

int main(void)
{
	printf("sizeof(float)           =%u\n", sizeof(float));
	printf("sizeof(double)          =%u\n", sizeof(double));
	printf("sizeof(long double)     =%u\n", sizeof(long double));

	getchar();
	return 0;
}