#include<stdio.h>
int main(void)
{
	int index, index_1;
	char ch;

	for (index = 0; index < 5; index++)
	{
		for (index_1 = 0; index_1 <= index; index_1++)
			printf("$");
		printf("\n");
	}

	getchar();
	return 0;
}