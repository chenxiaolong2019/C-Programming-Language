//��ӡ�ϳ����ַ���
#include <stdio.h>
int main(void)
{
	printf("Here's one way to print a ");
	printf("long string.\n");
	printf("Here's another way to print a \
long string.\n");
	printf("Here's newest way to print a "
		"long string.\n");   //ANSI C*
	
	getchar();

	return 0;
}