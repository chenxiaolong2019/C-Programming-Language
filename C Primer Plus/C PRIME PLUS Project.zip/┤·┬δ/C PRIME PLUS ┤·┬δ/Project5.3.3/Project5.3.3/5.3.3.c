//������ǰ׺�ͺ�׺
#include<stdio.h>
int main(void)
{
	int ultra = 0, super = 0;

	while (super < 5)
	{
		super++;
		++ultra;
		printf("spuer=%d,ultra=%d\n", super, ultra);
	}

	getchar();
	return 0;
}