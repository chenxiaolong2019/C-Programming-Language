#include<stdio.h>
#include<string.h>
int main(void)
{
	char FRIST_NAME[40];
	int a;

	char NAME[40];
	int b;

	int c;
	
	printf("�����������գ�");
	scanf("%s", FRIST_NAME);
    printf("\n");
	a = strlen(FRIST_NAME);

	printf("�������������֣�");
	scanf("%s", NAME);
	printf("\n");
	b = strlen(NAME);

	printf("%s %s\n", FRIST_NAME, NAME);
	printf("%*d ", a,a);
	printf("%*d", b,b);

	printf("\n");

	printf("%s %s\n", FRIST_NAME, NAME);
	printf("%-*d", a, a);
	printf(" %-*d", b, b);

	getchar();
	getchar();
	getchar();

	return 0;


}