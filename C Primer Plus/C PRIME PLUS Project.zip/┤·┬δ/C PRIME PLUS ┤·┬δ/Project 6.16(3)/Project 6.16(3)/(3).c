#include<stdio.h>
int main(void)
{
	char ch, letter;
	int index;
	int index_2;
	

	for (index = 0; index <= 5; index++)
	{
		for (letter = 'F', index_2 = 0; letter >= 'A', index_2 <= index; letter--, index_2++)

			printf("%c", letter);
			printf("\n");
		
	}
	getchar();
	return 0;
}