#include<stdio.h>

int main(void)
{
	int num1, num2, num3, num4, max;

	puts("�������ĸ�����:");
	scanf_s("%d %d %d %d", &num1, &num2, &num3, &num4);

	max = num1;

	if (num2 > num1)
		max = num2;
	if (num3 > num1)
		max = num3;
	if (num4 > num1)
		max = num4;

	printf("���ֵΪ%d", max);

	getchar();
	getchar();
	return 0;
}