#include<stdio.h>
const float cm_feet = 30.48;
const float cm_inches = 2.54;

int main(void)
{
	float heigh;
	float feet;
	float inches;

	printf("Enter a height in centimeters:");
	scanf("%f", &heigh);

	while (heigh != 0)
	{
		feet = heigh / cm_feet;
		inches = heigh / cm_inches;
		printf("%.1fcm = %f feet,%.1f inches\n\n", heigh, feet, inches);

		printf("Enter a height in centimeters(<=0 to quit):");
		scanf("%f", &heigh);
	}

	printf("bye");

	getchar();
	getchar();
	return 0;

}