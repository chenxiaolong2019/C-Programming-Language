#include<stdio.h>

int main(void)
{
	int num1, count,sum;
	sum = 0;

	printf("n��ֵ: ");
	scanf_s("%d", &num1);

	for (count = 0; count <= num1; count++)
		sum = sum + count;

	printf("��1��%d�ĺ�Ϊ%d", num1, sum);

	getchar();
	getchar();
	return 0;
}