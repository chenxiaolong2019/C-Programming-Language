#include<stdio.h>
#define NUMBER 5

void set_idx(int *v, int n);

int main(void)
{
	int n, v[NUMBER], i;

	n = NUMBER;
	set_idx(v, n);

	for (i = 0; i < n; i++)
		printf("v[%d] = %d\n ",i,v[i]);

	getchar();
	getchar();

	return 0;
}

void set_idx(int *v, int n)
{
	int i = 0;
	for (i = 0; i < n; i++)
	{
		v[i] = i;
	}
}