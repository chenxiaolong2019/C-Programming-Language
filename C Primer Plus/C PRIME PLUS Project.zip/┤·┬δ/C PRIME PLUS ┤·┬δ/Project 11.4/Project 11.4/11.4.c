//ָ�����飬�ַ�������
#include<stdio.h>
#define SLEN 40
#define LIM 5
int main(void)
{
	const char *mytalents[LIM] = {
		"Adding numbers switfly",
		"Multipling accurately","Stashing data",
		"Folling instructions to the letter",
		"Understanding the C language"
	};
	char yourtalents[LIM][SLEN] = {
		"Walking in straight line",
		"Sleeoing","Watching televison",
		"Mailing letters","Reading email"
	};
	int i;

	puts("Let's compers talents.");
	printf("%-36s %-25s\n", "My Talents", "Your talents");
	for (i = 0; i < LIM; i++)
		printf("%-36s %-25s\n", mytalents[i], yourtalents[i]);
	printf("\nsizeof mytalents: %zd, sizeof yourtalents: %zd\n", sizeof(mytalents), sizeof(yourtalents));

	getchar();
	return 0;
}