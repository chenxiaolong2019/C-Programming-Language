
#include <stdio.h>  
void copy_arr(const double source[], double target1[], int size);
void copy_ptr(const double *source, double *target2, double *end);
void print(const double ar[], int size);
int main(void)
{
	double source[5] = { 1.1,2.2,3.3,4.4,5.5 };
	double target1[5];
	double target2[5];
	int size = 5;

	printf("source array:\n");
	print(source, size);

	copy_arr(source, target1, size);
	printf("target1 array:\n");
	print(target1, size);
	copy_ptr(source, target2, source + size);
	printf("target2 array:\n");
	print(target2, size);

	getchar();
	return 0;
}
void copy_arr(const double source[], double target1[], int size)
{
	int i;
	for (i = 0; i < size; i++)
		target1[i] = source[i];
}
void copy_ptr(const double *source, double *target2, double *end)
{
	while (source < end)
	{
		*target2 = *source;
		source++;
		target2++;
	}
}
void print(const double ar[], int size)
{
	int i;
	for (i = 0; i < size; i++)
		printf("%.1f  ", ar[i]);
	printf("\n");
}
