#include<stdio.h>

int main(void)
{
	float a;
	printf("������һ������");

	scanf("%f", &a);

	printf("The input is %2.1f or %2.1e\n", a, a);

	printf("The input is %+2.3f or %2.3e\n", a, a);

	getchar();
	getchar();

	return 0;
}
