#include<stdio.h>
#define NUMBER 60

int main(void)
{
	int a, b,d;
	int c[NUMBER];
	
	printf("���ݸ���:");
	do
	{
		scanf_s("%d", &a);
		if (a < 1 || a>60)
			printf("������1��%d����", NUMBER);
	} while (a < 1 || a>60);

	for (b = 1; b <= a; b++)
	{
		printf("%d�ţ�",b);
		scanf_s("%d", &c[b-1]);
	}
	putchar('{');
	for(b = 0; b < a-1 ; b++)
		printf("%d, ", c[b]);
	printf("%d", c[a-1]);

	putchar('}');

	getchar();
	getchar();

	return 0;

}