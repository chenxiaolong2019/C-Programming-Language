#include <stdio.h>;

int main(void)
{
	int toes, a, squaretoes;

	toes = 10;
    a = 2 * 10;
	squaretoes = toes * toes;

	printf("toes=%d,double toes=%d,square toes=%d", toes, a, squaretoes);

	getchar();

	return 0;
}