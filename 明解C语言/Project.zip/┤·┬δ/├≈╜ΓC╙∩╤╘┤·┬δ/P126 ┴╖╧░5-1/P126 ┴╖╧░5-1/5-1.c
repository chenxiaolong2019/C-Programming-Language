#include<stdio.h>

int main(void)
{
	int i,a;
	int v[5];

	for (i = 0, a = 5; i < 5; i++)
	{
		v[i] = a;
		a--;
	}
	for (i = 0; i < 5; i++)
		printf("v[%d] = %d\n", i, v[i]);

	getchar();
	return 0;
}