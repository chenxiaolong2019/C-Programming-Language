#include<stdio.h>

int main(void)
{
	int num1, num2, num3, num4,num5,num6;

	printf("Please enter an integer:");
	scanf_s("%d", &num1);

	if (num1 <= 9)
		for (num2 = 1; num2 <= num1; num2++)
			printf("%d", num2);
	else
	{
		num4 = num1 / 10;
		num5 = num1 % 10;//  ������������Ϊ25 ��num5Ϊ5 

		for (num6 = 0; num6 < num4; num6++)
			printf("1234567890");
		for (num3 = 1; num3 <= num5; num3++)
			printf("%d", num3);
	}

	printf("\n");

	getchar();
	getchar();

	return 0;
}