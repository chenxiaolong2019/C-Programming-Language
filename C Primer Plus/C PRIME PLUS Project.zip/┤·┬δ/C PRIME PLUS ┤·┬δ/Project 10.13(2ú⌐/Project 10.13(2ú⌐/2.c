#include<stdio.h>
#define SIZE 5
int main(void)
{
	int number[SIZE] = { 1,2,3,4,5 };

}