#include<stdio.h>;

int main(void)
{
	float x=0,y;
	int i;

	for (i = 0; i <= 100; i++)
	{
		y = i / 100.0;
		printf("x = %f     x = %f\n", y,x);
		x += 0.01;
	}
	getchar();
	return 0;
}