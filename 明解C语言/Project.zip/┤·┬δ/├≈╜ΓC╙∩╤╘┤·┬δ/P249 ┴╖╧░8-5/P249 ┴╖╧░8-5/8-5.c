#include<stdio.h>

enum gender{man,woman};
enum season {spring,summer,autumn,winter};
enum gender select(void);
enum season select_1(void);


int main(void)
{
	enum gender selected;
	enum season selected_1;

	switch (selected = select())
	{
	case man:printf("MAN");
		break;
	case woman:printf("WOMAN");
		break;
	}
	
	switch (selected_1 = select_1())
	{
	case spring:printf("SPRING");
		break;
	case summer:printf("SUMMER");
		break;
	case autumn:printf("AUTUMN");
		break;
	case winter:printf("WINTER");
		break;
	}

	getchar();
	getchar();

	return 0;

}

enum gender select(void)
{
	int tmp;
	do
	{
		printf("�����������Ա�\n��......0   Ů......1");
		scanf_s("%d", &tmp);
	} while (tmp<0 || tmp>woman);

	return tmp;
}

enum season select_1(void)
{
	int tmp;
	do
	{
		printf("�����뼾��\n��......0   ��......1   ��......2   ��......3");
		scanf_s("%d", &tmp);
	} while (tmp<0 || tmp>winter);

	return tmp;
}