#include<stdio.h>
#define ROWS 4
int main(void)
{
	int row;
	int col;

	for (row = 0; row < ROWS; row++)
	{
		for (col = 1; col<=8; col++)
		{
			printf("$");
		}
		printf("\n");
	}

	getchar();
	return 0;
}