//C�е���ͼٵ�ֵ
#include<stdio.h>
int main(void)
{
	int ture_val, false_val;

	ture_val = (10 > 2);
	false_val = (10 == 2);
	printf("ture=%d;false=%d\n", ture_val, false_val);

	getchar();
	return 0;

}